#include<stdio.h>
int main()
{
	int a=10,b=0;
	printf("a&&b: %dn",a&&b);
	printf("a||b: %dn",a||b);
	printf("!a:%dn",!a);
	return 0;
}
