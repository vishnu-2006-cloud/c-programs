#include<stdio.h>
int main()
{
	int r;
	float s;
	printf("enter the values r,r");
	scanf("%d%d",&r,&r);
	s=3.14*r*r;
	printf("area is s=%.2f",s);
}
