#include<stdio.h>
int main()
{
	int a=0,b=1;
	printf("the values A && B%d",a & b,a);
	printf("\nthe values A || B%d",a || b,a);
	printf("\nthe values A | B%d",a | b,a);
	printf("\nthe values A ^ B%d",a ^ b,a);
}
