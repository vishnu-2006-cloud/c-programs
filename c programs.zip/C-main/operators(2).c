#include<stdio.h>
#include<math.h>
int main()
{
	int s;
	float h;
	printf("enter the value s");
	scanf("%d",&s);
	h=sqrt(s);
	printf("the value of sqrt(S)=%.2f",h);
}
