#include<stdio.h>
int main()
{
	int i,a[10];
	printf("enter one by one");
	for(i=0;i<10;i++)
	{
		scanf("%d",&a[i]);
		
	}
	for(i=0;i<10;i++)
	{
		printf("%d",a[i]);
	}
}
