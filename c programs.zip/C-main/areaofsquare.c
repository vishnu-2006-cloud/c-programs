#include<stdio.h>
int main ()
{
	int h;
	float s;
	printf("enter the value h,h");
	scanf("%d%d",&h,&h);
	s=h*h;
	printf("area is s:%.2f",s);
}
