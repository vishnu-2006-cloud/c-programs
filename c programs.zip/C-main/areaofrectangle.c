#include<stdio.h>
int main()
{
	int a,b,s;
	printf("enter the values:a,b");
	scanf("%d%d",&a,&b);
	s=a*b;
	printf("area is:s=%d",s);
}
