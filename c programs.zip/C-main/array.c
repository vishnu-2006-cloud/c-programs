#include<stdio.h>
int main()
{
	int array[100],n,c,d,swap;
	printf("enter number of elements\n");
	scanf("%d",&n);
	printf("enter the number");
	for(c=0;c<n;c++)
	scanf("%d",&a[c]);
	for(c=0;c<n-1;c++)
}
    for(d=o;d<n-c-1;d++)
    {
    	if(array[d]>array[d+1].1*/for decreasing
    	or use '<' instead of'>',*/
	}
	swap=array[d];
	array[d]=array[d+1];
	array[d+1]=swap;
	}
}
}
printf("sorted in ascending order\n");
for(c=0;c<n;c++)
printf("%d\n",array[c]);

return 0;
}
