#include<stdio.h>
int main ()
{
	int a,b,c,d,T;
	printf("enter the values of a,b,c,d");
	scanf("%d%d%d%d",&a,&b,&c,&d);
	T=a/b*c-b+a*d/3
	printf("the values of the expression is :%2d,T");
}
