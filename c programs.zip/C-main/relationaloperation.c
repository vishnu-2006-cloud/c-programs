/*relational operation*/
#include<stdio.h>
int main()
{
	int a,b;
	printf("enter the a and b values:-");
	scanf("%d%d",&a,&b);
	if(a<=b)
	if(a==b)
	{
		printf("both are equal");
	}
	else
	{
		printf("both are not equal");
	}
}
