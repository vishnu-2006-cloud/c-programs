#include<stdio.h>
int main()
{
	int a=6;
	printf("the value of a is %d");
}
