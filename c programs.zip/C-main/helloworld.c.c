#include<stdio.h>
int main()
{
	printf("welcome to c programming");
}
